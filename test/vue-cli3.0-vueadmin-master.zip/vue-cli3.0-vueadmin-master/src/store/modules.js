import permission from './modules/permission'

export default {
    permission
}
