# vue-cli3.x-configure
基于vue-cli3.x下，配合vuex、vue-router、iView、axios、scss、amfe-flexible、vConsole等等.
我对SessionLogs.vue做了pxtorem的编译，用的是局部转换 postcss-px2rem-exclude
调试工具我用的是vConsole,在public/index.html的head中我注释另一个工具eruda
## 配合自动化后处理命令会让你的项目事半功倍，https://github.com/trsoliu/vue-cli3-command（一键build后改名加版本号，压缩，上传，发布等等）
## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Run your unit tests
```
npm run test:unit
```

### Run your end-to-end tests
```
npm run test:e2e
```
