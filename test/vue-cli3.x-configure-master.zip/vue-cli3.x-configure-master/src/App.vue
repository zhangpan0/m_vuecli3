<template>
	<div id="app">
		<router-view/>
	</div>
</template>

<style lang="scss">
	@import "./assets/font/iconfont.css";
	html,
	body,
	#app {
		width: 100%;
		height: 100%;
	}
	
	[v-cloak] {
		display: none;
	}
	
</style>