<template>
	<div class="main" id="main" >
		demo-main
	</div>
</template>
<script>
	export default {
		name: "main",
		created() {},
		components: {}
	};
</script>
<style lang="scss" scoped>
	.main {
		width: 100%;
		height: 100%;
		position: absolute;
		top: 0;
		bottom: 0;
		left: 0;
		min-width: 1300px;
		overflow-x: auto;
		overflow-y: hidden;
	}
</style>