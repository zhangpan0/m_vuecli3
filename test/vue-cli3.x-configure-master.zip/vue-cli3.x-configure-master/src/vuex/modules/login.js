//状态types
const types = {
//LOGIN_LOADING_STATUS: "LOGIN_LOADING_STATUS" //加载状态
};
/**
 * App通用配置
 */
const state = {
  loading: false
};

const actions = {
  //  setLoadingState({ commit }, status) {
  //      commit(types.LOGIN_LOADING_STATUS, status)
  //  },
  //
};

const getters = {
  //  loading: state => state.loading,
  //  showToast: state => state.showToast,
  //  showAlert: state => state.showAlert
};

const mutations = {
  //  [types.LOGIN_LOADING_STATUS](state, status) {
  //      state.loading1 = status
  //  },
};

export default {
  state,
  actions,
  getters,
  mutations
};
