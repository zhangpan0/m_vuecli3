// 正式
module.exports = {
  title: 'vue-h5-template',
  api: {
    base_api: 'https://xxx.xxx.com/admin',
    common_api: 'https://xxx.xxx.com/common'
  }
}
